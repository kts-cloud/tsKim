object frmTest_L: TfrmTest_L
  Left = 0
  Top = 0
  Caption = 'frmTest_L'
  ClientHeight = 894
  ClientWidth = 1454
  Color = clBtnFace
  DefaultMonitor = dmDesktop
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  FormStyle = fsMDIChild
  OldCreateOrder = False
  Visible = True
  OnCloseQuery = FormCloseQuery
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 13
  object imgCheckBox: TImage
    Left = 727
    Top = 26
    Width = 105
    Height = 19
    Picture.Data = {
      07544269746D6170C20E0000424DC20E0000000000003604000028000000B400
      00000F00000001000800000000008C0A0000230B0000230B0000000100000001
      000000000000330000006600000099000000CC000000FF000000003300003333
      00006633000099330000CC330000FF3300000066000033660000666600009966
      0000CC660000FF66000000990000339900006699000099990000CC990000FF99
      000000CC000033CC000066CC000099CC0000CCCC0000FFCC000000FF000033FF
      000066FF000099FF0000CCFF0000FFFF00000000330033003300660033009900
      3300CC003300FF00330000333300333333006633330099333300CC333300FF33
      330000663300336633006666330099663300CC663300FF663300009933003399
      33006699330099993300CC993300FF99330000CC330033CC330066CC330099CC
      3300CCCC3300FFCC330000FF330033FF330066FF330099FF3300CCFF3300FFFF
      330000006600330066006600660099006600CC006600FF006600003366003333
      66006633660099336600CC336600FF3366000066660033666600666666009966
      6600CC666600FF66660000996600339966006699660099996600CC996600FF99
      660000CC660033CC660066CC660099CC6600CCCC6600FFCC660000FF660033FF
      660066FF660099FF6600CCFF6600FFFF66000000990033009900660099009900
      9900CC009900FF00990000339900333399006633990099339900CC339900FF33
      990000669900336699006666990099669900CC669900FF669900009999003399
      99006699990099999900CC999900FF99990000CC990033CC990066CC990099CC
      9900CCCC9900FFCC990000FF990033FF990066FF990099FF9900CCFF9900FFFF
      99000000CC003300CC006600CC009900CC00CC00CC00FF00CC000033CC003333
      CC006633CC009933CC00CC33CC00FF33CC000066CC003366CC006666CC009966
      CC00CC66CC00FF66CC000099CC003399CC006699CC009999CC00CC99CC00FF99
      CC0000CCCC0033CCCC0066CCCC0099CCCC00CCCCCC00FFCCCC0000FFCC0033FF
      CC0066FFCC0099FFCC00CCFFCC00FFFFCC000000FF003300FF006600FF009900
      FF00CC00FF00FF00FF000033FF003333FF006633FF009933FF00CC33FF00FF33
      FF000066FF003366FF006666FF009966FF00CC66FF00FF66FF000099FF003399
      FF006699FF009999FF00CC99FF00FF99FF0000CCFF0033CCFF0066CCFF0099CC
      FF00CCCCFF00FFCCFF0000FFFF0033FFFF0066FFFF0099FFFF00CCFFFF00FFFF
      FF00000080000080000000808000800000008000800080800000C0C0C0008080
      8000191919004C4C4C00B2B2B200E5E5E500C8AC2800E0CC6600F2EABF00B59B
      2400D8E9EC0099336600D075A300ECC6D900646F710099A8AC00E2EFF1000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000DADA0808080808080808080808DADADADADADADADADA0808080808080808
      080808DADADADADADADADADA0808080808080808080808DADADADADADADADADA
      0808080808080808080808DADADADADADADADADA0808080808080808080808DA
      DADADADADADADADA0808080808080808080808DADADADADADADADADAECECECEC
      ECECECECECECECDADADADADADADADADAECECECECECECECECECECECDADADADADA
      DADADADAECECECECECECECECECECECDADADADADADADADADA081E1E1E1E1E1E1E
      1E1E08DADADADADADADADADA081E1E1E1E1E1E1E1E1E08DADADADADADADADADA
      081E1E1E1E1E1E1E1E1E08DADADADADADADADADA08E8E8E8E8E8E8E8E8E808DA
      DADADADADADADADA08E8E8E8E8E8E8E8E8E808DADADADADADADADADA08E8E8E8
      E8E8E8E8E8E808DADADADADADADADADAECACACACACACACACACACECDADADADADA
      DADADADAECACACACACACACACACACECDADADADADADADADADAECACACACACACACAC
      ACACECDADADADADADADADADA081E1E1E1E1E1E1E1E1E08DADADADADADADADADA
      081E1E1E1E09091E1E1E08DADADADADADADADADA081E090909090909091E08DA
      DADADADADADADADA08E8E8E8E8E8E8E8E8E808DADADADADADADADADA08E8E8E8
      E80909E8E8E808DADADADADADADADADA08E809090909090909E808DADADADADA
      DADADADAECACACACACACACACACACECDADADADADADADADADAECACACACAC8181AC
      ACACECDADADADADADADADADAECAC81818181818181ACECDADADADADADADADADA
      081E1E1E1E1E1E1E1E1E08DADADADADADADADADA081E1E1E091010091E1E08DA
      DADADADADADADADA081E091010101010091E08DADADADADADADADADA08E8E8E8
      E8E8E8E8E8E808DADADADADADADADADA08E8E8E809101009E8E808DADADADADA
      DADADADA08E809101010101009E808DADADADADADADADADAECACACACACACACAC
      ACACECDADADADADADADADADAECACACAC81ACAC81ACACECDADADADADADADADADA
      ECAC81ACACACACAC81ACECDADADADADADADADADA081E1E1E1E1E1E1E1E1E08DA
      DADADADADADADADA081E1E0910101010091E08DADADADADADADADADA081E0910
      10101010091E08DADADADADADADADADA08E8E8E8E8E8E8E8E8E808DADADADADA
      DADADADA08E8E8091010101009E808DADADADADADADADADA08E8091010101010
      09E808DADADADADADADADADAECACACACACACACACACACECDADADADADADADADADA
      ECACAC81ACACACAC81ACECDADADADADADADADADAECAC81ACACACACAC81ACECDA
      DADADADADADADADA081E1E1E1E1E1E1E1E1E08DADADADADADADADADA081E0910
      10101010100908DADADADADADADADADA081E091010101010091E08DADADADADA
      DADADADA08E8E8E8E8E8E8E8E8E808DADADADADADADADADA08E8091010101010
      100908DADADADADADADADADA08E809101010101009E808DADADADADADADADADA
      ECACACACACACACACACACECDADADADADADADADADAECAC81ACACACACACAC81ECDA
      DADADADADADADADAECAC81ACACACACAC81ACECDADADADADADADADADA081E1E1E
      1E1E1E1E1E1E08DADADADADADADADADA081E091010090910101009DADADADADA
      DADADADA081E091010101010091E08DADADADADADADADADA08E8E8E8E8E8E8E8
      E8E808DADADADADADADADADA08E8091010090910101009DADADADADADADADADA
      08E809101010101009E808DADADADADADADADADAECACACACACACACACACACECDA
      DADADADADADADADAECAC81ACAC8181ACACAC81DADADADADADADADADAECAC81AC
      ACACACAC81ACECDADADADADADADADADA081E1E1E1E1E1E1E1E1E08DADADADADA
      DADADADA081E0910091E1E0910101009DADADADADADADADA081E091010101010
      091E08DADADADADADADADADA08E8E8E8E8E8E8E8E8E808DADADADADADADADADA
      08E8091009E8E80910101009DADADADADADADADA08E809101010101009E808DA
      DADADADADADADADAECACACACACACACACACACECDADADADADADADADADAECAC81AC
      81ACAC81ACACAC81DADADADADADADADAECAC81ACACACACAC81ACECDADADADADA
      DADADADA081E1E1E1E1E1E1E1E1E08DADADADADADADADADA081E09091E1E1E1E
      0910101009DADADADADADADA081E090909090909091E08DADADADADADADADADA
      08E8E8E8E8E8E8E8E8E808DADADADADADADADADA08E80909E8E8E8E809101010
      09DADADADADADADA08E809090909090909E808DADADADADADADADADAECACACAC
      ACACACACACACECDADADADADADADADADAECAC8181ACACACAC81ACACAC81DADADA
      DADADADAECAC81818181818181ACECDADADADADADADADADA081E1E1E1E1E1E1E
      1E1E08DADADADADADADADADA081E1E1E1E1E1E1E1E0910101009DADADADADADA
      081E1E1E1E1E1E1E1E1E08DADADADADADADADADA08E8E8E8E8E8E8E8E8E808DA
      DADADADADADADADA08E8E8E8E8E8E8E8E80910101009DADADADADADA08E8E8E8
      E8E8E8E8E8E808DADADADADADADADADAECACACACACACACACACACECDADADADADA
      DADADADAECACACACACACACACAC81ACACAC81DADADADADADAECACACACACACACAC
      ACACECDADADADADADADADADA0808080808080808080808DADADADADADADADADA
      080808080808080808080910101009DADADADADA0808080808080808080808DA
      DADADADADADADADA0808080808080808080808DADADADADADADADADA08080808
      0808080808080910101009DADADADADA0808080808080808080808DADADADADA
      DADADADAECECECECECECECECECECECDADADADADADADADADAECECECECECECECEC
      ECEC81ACACAC81DADADADADAECECECECECECECECECECECDADADADADADADADADA
      DADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADA09
      101009DADADADADADADADADADADADADADADADADADADADADADADADADADADADADA
      DADADADADADADADADADADADADADADADADADADADADADADADADADADA09101009DA
      DADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADA
      DADADADADADADADADADADADADADADADADADADADADADADA81ACAC81DADADADADA
      DADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADA
      DADADADADADADADADADADADADADADADADADADADA091009DADADADADADADADADA
      DADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADA
      DADADADADADADADADADADADADADADADA091009DADADADADADADADADADADADADA
      DADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADA
      DADADADADADADADADADADADA81AC81DADADADADADADADADADADADADADADADADA
      DADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADA
      DADADADADADADADADA0909DADADADADADADADADADADADADADADADADADADADADA
      DADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADA
      DADADADADA0909DADADADADADADADADADADADADADADADADADADADADADADADADA
      DADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADA
      DA8181DADADADADADADADADADADADADADADADADADADADADADADADADADADADADA
      DADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADA
      DADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADA
      DADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADA
      DADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADA
      DADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADADA
      DADADADADADADADADADADADADADA}
    Visible = False
  end
  object pnlInputSerial: TRzPanel
    Left = 676
    Top = 150
    Width = 794
    Height = 225
    BorderInner = fsGroove
    BorderWidth = 1
    Caption = 'St'
    TabOrder = 0
    Visible = False
    object btnInputSerial: TRzBitBtn
      Left = 224
      Top = 175
      Width = 150
      Height = 37
      Cursor = crHandPoint
      FrameColor = 7617536
      Caption = 'Report'
      Color = 15791348
      Font.Charset = ANSI_CHARSET
      Font.Color = clWindowText
      Font.Height = -13
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      HotTrack = True
      ParentFont = False
      TabOrder = 3
      Glyph.Data = {
        36060000424D3606000000000000360400002800000020000000100000000100
        08000000000000020000430C0000430C00000001000000000000000000003300
        00006600000099000000CC000000FF0000000033000033330000663300009933
        0000CC330000FF33000000660000336600006666000099660000CC660000FF66
        000000990000339900006699000099990000CC990000FF99000000CC000033CC
        000066CC000099CC0000CCCC0000FFCC000000FF000033FF000066FF000099FF
        0000CCFF0000FFFF000000003300330033006600330099003300CC003300FF00
        330000333300333333006633330099333300CC333300FF333300006633003366
        33006666330099663300CC663300FF6633000099330033993300669933009999
        3300CC993300FF99330000CC330033CC330066CC330099CC3300CCCC3300FFCC
        330000FF330033FF330066FF330099FF3300CCFF3300FFFF3300000066003300
        66006600660099006600CC006600FF0066000033660033336600663366009933
        6600CC336600FF33660000666600336666006666660099666600CC666600FF66
        660000996600339966006699660099996600CC996600FF99660000CC660033CC
        660066CC660099CC6600CCCC6600FFCC660000FF660033FF660066FF660099FF
        6600CCFF6600FFFF660000009900330099006600990099009900CC009900FF00
        990000339900333399006633990099339900CC339900FF339900006699003366
        99006666990099669900CC669900FF6699000099990033999900669999009999
        9900CC999900FF99990000CC990033CC990066CC990099CC9900CCCC9900FFCC
        990000FF990033FF990066FF990099FF9900CCFF9900FFFF99000000CC003300
        CC006600CC009900CC00CC00CC00FF00CC000033CC003333CC006633CC009933
        CC00CC33CC00FF33CC000066CC003366CC006666CC009966CC00CC66CC00FF66
        CC000099CC003399CC006699CC009999CC00CC99CC00FF99CC0000CCCC0033CC
        CC0066CCCC0099CCCC00CCCCCC00FFCCCC0000FFCC0033FFCC0066FFCC0099FF
        CC00CCFFCC00FFFFCC000000FF003300FF006600FF009900FF00CC00FF00FF00
        FF000033FF003333FF006633FF009933FF00CC33FF00FF33FF000066FF003366
        FF006666FF009966FF00CC66FF00FF66FF000099FF003399FF006699FF009999
        FF00CC99FF00FF99FF0000CCFF0033CCFF0066CCFF0099CCFF00CCCCFF00FFCC
        FF0000FFFF0033FFFF0066FFFF0099FFFF00CCFFFF00FFFFFF00000080000080
        000000808000800000008000800080800000C0C0C00080808000191919004C4C
        4C00B2B2B200E5E5E500C8AC2800E0CC6600F2EABF00B59B2400D8E9EC009933
        6600D075A300ECC6D900646F710099A8AC00E2EFF10000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000E8E8E8E8E8E8
        E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
        E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
        E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
        E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8030303
        03030303030303E8E8E8E8E8E881818181818181818181E8E8E8E8E803040404
        0404030403030303E8E8E8E881E2E2E2E2E281E281818181E8E8E8E803050404
        0404040304030303E8E8E8E881ACE2E2E2E2E281E2818181E8E8E8E803040504
        0404040403040303E8E8E8E881E2ACE2E2E2E2E281E28181E8E8E8E803050405
        0404040404030403E8E8E8E881ACE2ACE2E2E2E2E281E281E8E8E8E803050504
        0504040404040303E8E8E8E881ACACE2ACE2E2E2E2E28181E8E8E8E8035F0505
        0405040404040403E8E8E8E881E3ACACE2ACE2E2E2E2E281E8E8E8E8035F5F05
        0504050404040403E8E8E8E881E3E3ACACE2ACE2E2E2E281E8E8E8E8E8030303
        03030303030303E8E8E8E8E8E881818181818181818181E8E8E8E8E8E8E8E8E8
        E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
        E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
        E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8}
      NumGlyphs = 2
    end
    object pnlInputS1: TRzPanel
      Left = 12
      Top = 12
      Width = 769
      Height = 50
      BorderOuter = fsFlatRounded
      BorderColor = clBlack
      BorderWidth = 1
      TabOrder = 0
      object pnl4: TRzPanel
        Left = 3
        Top = 3
        Width = 82
        Height = 44
        Align = alLeft
        BorderInner = fsStatus
        BorderOuter = fsPopup
        Caption = 'Channel 1'
        Color = 16737894
        Font.Charset = ANSI_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'Tahoma'
        Font.Style = [fsBold]
        GradientColorStyle = gcsCustom
        GradientColorStart = 16730698
        GradientColorStop = 16776176
        ParentFont = False
        TabOrder = 0
      end
      object edSerial1: TRzEdit
        Tag = 1
        Left = 85
        Top = 3
        Width = 681
        Height = 44
        Text = ''
        Align = alClient
        CharCase = ecUpperCase
        Color = clBlack
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clLime
        Font.Height = -32
        Font.Name = 'Tahoma'
        Font.Style = []
        ImeName = 'Microsoft Office IME 2007'
        MaxLength = 100
        ParentFont = False
        ReadOnlyColor = clBlack
        TabOnEnter = True
        TabOrder = 1
        ExplicitHeight = 47
      end
    end
    object pnlInputS2: TRzPanel
      Left = 12
      Top = 62
      Width = 769
      Height = 50
      BorderOuter = fsFlatRounded
      BorderColor = clBlack
      BorderWidth = 1
      TabOrder = 1
      object pnl5: TRzPanel
        Left = 3
        Top = 3
        Width = 82
        Height = 44
        Align = alLeft
        BorderInner = fsStatus
        BorderOuter = fsPopup
        Caption = 'Channel 2'
        Color = 16737894
        Font.Charset = ANSI_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'Tahoma'
        Font.Style = [fsBold]
        GradientColorStyle = gcsCustom
        GradientColorStart = 16730698
        GradientColorStop = 16776176
        ParentFont = False
        TabOrder = 0
      end
      object edSerial2: TRzEdit
        Left = 85
        Top = 3
        Width = 681
        Height = 44
        Text = ''
        Align = alClient
        CharCase = ecUpperCase
        Color = clBlack
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clLime
        Font.Height = -32
        Font.Name = 'Tahoma'
        Font.Style = []
        ImeName = 'Microsoft Office IME 2007'
        MaxLength = 100
        ParentFont = False
        ReadOnlyColor = clBlack
        TabOnEnter = True
        TabOrder = 1
        ExplicitHeight = 47
      end
    end
    object pnlInputS3: TRzPanel
      Left = 12
      Top = 112
      Width = 769
      Height = 50
      BorderOuter = fsFlatRounded
      BorderColor = clBlack
      BorderWidth = 1
      TabOrder = 2
      object pnl6: TRzPanel
        Left = 3
        Top = 3
        Width = 82
        Height = 44
        Align = alLeft
        BorderInner = fsStatus
        BorderOuter = fsPopup
        Caption = 'Channel 3'
        Color = 16737894
        Font.Charset = ANSI_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'Tahoma'
        Font.Style = [fsBold]
        GradientColorStyle = gcsCustom
        GradientColorStart = 16730698
        GradientColorStop = 16776176
        ParentFont = False
        TabOrder = 0
      end
      object edSerial3: TRzEdit
        Left = 85
        Top = 3
        Width = 681
        Height = 44
        Text = ''
        Align = alClient
        CharCase = ecUpperCase
        Color = clBlack
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clLime
        Font.Height = -32
        Font.Name = 'Tahoma'
        Font.Style = []
        ImeName = 'Microsoft Office IME 2007'
        MaxLength = 100
        ParentFont = False
        ReadOnlyColor = clBlack
        TabOnEnter = True
        TabOrder = 1
        ExplicitHeight = 47
      end
    end
    object btnStopInputS: TRzBitBtn
      Left = 445
      Top = 175
      Width = 150
      Height = 37
      Cursor = crHandPoint
      FrameColor = 7617536
      Caption = 'Stop'
      Color = 15791348
      Font.Charset = ANSI_CHARSET
      Font.Color = clWindowText
      Font.Height = -13
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      HotTrack = True
      ParentFont = False
      TabOrder = 4
      TabStop = False
      Glyph.Data = {
        36060000424D3606000000000000360400002800000020000000100000000100
        08000000000000020000E30E0000E30E00000001000000000000000000003300
        00006600000099000000CC000000FF0000000033000033330000663300009933
        0000CC330000FF33000000660000336600006666000099660000CC660000FF66
        000000990000339900006699000099990000CC990000FF99000000CC000033CC
        000066CC000099CC0000CCCC0000FFCC000000FF000033FF000066FF000099FF
        0000CCFF0000FFFF000000003300330033006600330099003300CC003300FF00
        330000333300333333006633330099333300CC333300FF333300006633003366
        33006666330099663300CC663300FF6633000099330033993300669933009999
        3300CC993300FF99330000CC330033CC330066CC330099CC3300CCCC3300FFCC
        330000FF330033FF330066FF330099FF3300CCFF3300FFFF3300000066003300
        66006600660099006600CC006600FF0066000033660033336600663366009933
        6600CC336600FF33660000666600336666006666660099666600CC666600FF66
        660000996600339966006699660099996600CC996600FF99660000CC660033CC
        660066CC660099CC6600CCCC6600FFCC660000FF660033FF660066FF660099FF
        6600CCFF6600FFFF660000009900330099006600990099009900CC009900FF00
        990000339900333399006633990099339900CC339900FF339900006699003366
        99006666990099669900CC669900FF6699000099990033999900669999009999
        9900CC999900FF99990000CC990033CC990066CC990099CC9900CCCC9900FFCC
        990000FF990033FF990066FF990099FF9900CCFF9900FFFF99000000CC003300
        CC006600CC009900CC00CC00CC00FF00CC000033CC003333CC006633CC009933
        CC00CC33CC00FF33CC000066CC003366CC006666CC009966CC00CC66CC00FF66
        CC000099CC003399CC006699CC009999CC00CC99CC00FF99CC0000CCCC0033CC
        CC0066CCCC0099CCCC00CCCCCC00FFCCCC0000FFCC0033FFCC0066FFCC0099FF
        CC00CCFFCC00FFFFCC000000FF003300FF006600FF009900FF00CC00FF00FF00
        FF000033FF003333FF006633FF009933FF00CC33FF00FF33FF000066FF003366
        FF006666FF009966FF00CC66FF00FF66FF000099FF003399FF006699FF009999
        FF00CC99FF00FF99FF0000CCFF0033CCFF0066CCFF0099CCFF00CCCCFF00FFCC
        FF0000FFFF0033FFFF0066FFFF0099FFFF00CCFFFF00FFFFFF00000080000080
        000000808000800000008000800080800000C0C0C00080808000191919004C4C
        4C00B2B2B200E5E5E500C8AC2800E0CC6600F2EABF00B59B2400D8E9EC009933
        6600D075A300ECC6D900646F710099A8AC00E2EFF10000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000E8E8E8E8E8E8
        E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
        E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
        E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
        E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E86C6C6C
        6C6C6C6C6C6C6CE8E8E8E8E8E881818181818181818181E8E8E8E8E86C909090
        90906C906C6C6C6CE8E8E8E881E2E2E2E2E281E281818181E8E8E8E86CB49090
        9090906C906C6C6CE8E8E8E881ACE2E2E2E2E281E2818181E8E8E8E86C90B490
        909090906C906C6CE8E8E8E881E2ACE2E2E2E2E281E28181E8E8E8E86CB490B4
        90909090906C906CE8E8E8E881ACE2ACE2E2E2E2E281E281E8E8E8E86CB4B490
        B490909090906C6CE8E8E8E881ACACE2ACE2E2E2E2E28181E8E8E8E86CC9B4B4
        90B490909090906CE8E8E8E881E3ACACE2ACE2E2E2E2E281E8E8E8E86CC9C9B4
        B490B4909090906CE8E8E8E881E3E3ACACE2ACE2E2E2E281E8E8E8E8E86C6C6C
        6C6C6C6C6C6C6CE8E8E8E8E8E881818181818181818181E8E8E8E8E8E8E8E8E8
        E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
        E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
        E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8}
      NumGlyphs = 2
    end
  end
  object PageControl: TRzPageControl
    Left = 0
    Top = 0
    Width = 1454
    Height = 894
    Hint = ''
    ActivePage = tabSheet2
    Align = alClient
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ImagePosition = ipBottom
    ParentFont = False
    TextOrientation = orVertical
    TabIndex = 0
    TabOrder = 1
    TabOrientation = toLeft
    TabSequence = tsReverse
    FixedDimension = 23
    object tabSheet2: TRzTabSheet
      Caption = 'PROCESS'
      object pnlChInfo: TRzPanel
        Left = 0
        Top = 0
        Width = 1429
        Height = 645
        Align = alTop
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentFont = False
        TabOrder = 0
        object pnlErrAlram: TAdvPanel
          Left = 264
          Top = 264
          Width = 737
          Height = 193
          Color = clActiveCaption
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = []
          ParentFont = False
          TabOrder = 0
          UseDockManager = True
          Visible = False
          Version = '2.5.7.1'
          CanMove = True
          Caption.Color = clHighlight
          Caption.ColorTo = clNone
          Caption.CloseButton = True
          Caption.Flat = True
          Caption.Font.Charset = ANSI_CHARSET
          Caption.Font.Color = clWhite
          Caption.Font.Height = -13
          Caption.Font.Name = 'Verdana'
          Caption.Font.Style = []
          Caption.Indent = 0
          Caption.ShadeType = stLMetal
          Caption.Shape = csSemiRounded
          Caption.Text = '<B> Power Error Message </B>'
          Caption.Visible = True
          DoubleBuffered = True
          StatusBar.Font.Charset = DEFAULT_CHARSET
          StatusBar.Font.Color = clWindowText
          StatusBar.Font.Height = -11
          StatusBar.Font.Name = 'Tahoma'
          StatusBar.Font.Style = []
          Text = ''
          FullHeight = 200
          object pnlErrAlramMsg: TPanel
            Left = 1
            Top = 65
            Width = 735
            Height = 93
            Align = alClient
            Caption = 'Power Limit Error'
            Color = clRed
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlack
            Font.Height = -19
            Font.Name = 'Tahoma'
            Font.Style = [fsBold]
            ParentBackground = False
            ParentFont = False
            TabOrder = 0
            StyleElements = [seBorder]
          end
          object btnErrorDisplay: TRzButton
            Left = 1
            Top = 158
            Width = 735
            Height = 34
            Align = alBottom
            Caption = 'Close'
            HotTrack = True
            TabOrder = 1
            TabStop = False
          end
          object pnl2: TPanel
            Left = 1
            Top = 19
            Width = 735
            Height = 46
            Align = alTop
            Caption = 'Power Alarm'
            Color = clBlack
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWhite
            Font.Height = -19
            Font.Name = 'Tahoma'
            Font.Style = []
            ParentBackground = False
            ParentFont = False
            TabOrder = 2
            StyleElements = [seBorder]
          end
        end
      end
      object pnlTestInfo: TRzPanel
        Left = 0
        Top = 645
        Width = 1429
        Height = 247
        Align = alClient
        TabOrder = 1
        object RzPanel3: TRzPanel
          Left = 2
          Top = 2
          Width = 615
          Height = 243
          Align = alLeft
          BorderOuter = fsFlat
          TabOrder = 0
          object grpPPreview: TRzGroupBox
            Left = 1
            Top = 1
            Width = 204
            Height = 241
            Align = alLeft
            Caption = 'Pattern Preview'
            CaptionFont.Charset = ANSI_CHARSET
            CaptionFont.Color = 7879740
            CaptionFont.Height = -11
            CaptionFont.Name = 'Verdana'
            CaptionFont.Style = [fsBold]
            Font.Charset = ANSI_CHARSET
            Font.Color = 7879740
            Font.Height = -11
            Font.Name = 'Verdana'
            Font.Style = [fsBold]
            GradientColorStop = 16763080
            GroupStyle = gsBanner
            ParentColor = True
            ParentFont = False
            TabOrder = 0
            object RzPanel17: TRzPanel
              Left = 0
              Top = 45
              Width = 204
              Height = 196
              Align = alClient
              BorderOuter = fsStatus
              Color = 16119543
              TabOrder = 1
              object DongaPat: TDongaPat
                Left = 1
                Top = 1
                Width = 202
                Height = 194
                Align = alClient
                DongaImgWidth = 640
                DongaImgHight = 1136
                DongaUseSpc = True
                ExplicitLeft = 56
                ExplicitTop = 162
                ExplicitWidth = 105
                ExplicitHeight = 105
              end
              object lnSigoff1: TRzLine
                Left = 1
                Top = 1
                Width = 202
                Height = 194
                LineColor = clYellow
                LineSlope = lsUp
                LineWidth = 2
                Align = alClient
                Caption = 'Signal Off'
                Font.Charset = ANSI_CHARSET
                Font.Color = clYellow
                Font.Height = -11
                Font.Name = 'Verdana'
                Font.Style = [fsBold]
                ParentFont = False
                ExplicitLeft = 2
                ExplicitTop = 2
                ExplicitWidth = 167
                ExplicitHeight = 330
              end
              object lnSigoff2: TRzLine
                Left = 1
                Top = 1
                Width = 202
                Height = 194
                LineColor = clYellow
                LineWidth = 2
                Align = alClient
                Caption = 'Signal Off'
                Font.Charset = ANSI_CHARSET
                Font.Color = clYellow
                Font.Height = -11
                Font.Name = 'Verdana'
                Font.Style = [fsBold]
                ParentFont = False
                ExplicitLeft = 2
                ExplicitTop = 2
                ExplicitWidth = 167
                ExplicitHeight = 330
              end
            end
            object pnlPatternName: TPanel
              Left = 0
              Top = 21
              Width = 204
              Height = 24
              Align = alTop
              Caption = 'pnlPatternName'
              Color = clBlack
              Font.Charset = ANSI_CHARSET
              Font.Color = clYellow
              Font.Height = -11
              Font.Name = 'Verdana'
              Font.Style = [fsBold]
              ParentBackground = False
              ParentFont = False
              TabOrder = 0
              StyleElements = [seBorder]
            end
          end
          object grpResiPList: TRzGroupBox
            Left = 205
            Top = 1
            Width = 409
            Height = 241
            Align = alClient
            Caption = 'Registered Pattern List'
            Font.Charset = DEFAULT_CHARSET
            Font.Color = 7879740
            Font.Height = -11
            Font.Name = 'Tahoma'
            Font.Style = [fsBold]
            GradientColorStop = 16763080
            GroupStyle = gsBanner
            ParentColor = True
            ParentFont = False
            TabOrder = 1
            object HdrTimes: THeader
              Left = 0
              Top = 45
              Width = 409
              Height = 19
              Align = alTop
              AllowResize = False
              BorderStyle = bsNone
              Font.Charset = ANSI_CHARSET
              Font.Color = 7879740
              Font.Height = -11
              Font.Name = 'Verdana'
              Font.Style = [fsBold]
              ParentFont = False
              Sections.Sections = (
                #0'235'#0'Pattern Name'
                #0'57'#0'Options')
              TabOrder = 1
            end
            object pnlPatGrp: TPanel
              Left = 0
              Top = 21
              Width = 409
              Height = 24
              Align = alTop
              Caption = 'pnlPatGrp'
              Color = clBlack
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clYellow
              Font.Height = -11
              Font.Name = 'Tahoma'
              Font.Style = [fsBold]
              ParentBackground = False
              ParentFont = False
              TabOrder = 0
              StyleElements = [seBorder]
            end
            object gridPatternList: TAdvStringGrid
              Left = 0
              Top = 64
              Width = 409
              Height = 177
              Cursor = crDefault
              Align = alClient
              DrawingStyle = gdsClassic
              FixedCols = 0
              FixedRows = 0
              ScrollBars = ssBoth
              TabOrder = 2
              OnClick = gridPatternListClick
              HoverRowCells = [hcNormal, hcSelected]
              ActiveCellFont.Charset = DEFAULT_CHARSET
              ActiveCellFont.Color = clWindowText
              ActiveCellFont.Height = -11
              ActiveCellFont.Name = 'Tahoma'
              ActiveCellFont.Style = [fsBold]
              ControlLook.FixedGradientHoverFrom = clGray
              ControlLook.FixedGradientHoverTo = clWhite
              ControlLook.FixedGradientDownFrom = clGray
              ControlLook.FixedGradientDownTo = clSilver
              ControlLook.DropDownHeader.Font.Charset = DEFAULT_CHARSET
              ControlLook.DropDownHeader.Font.Color = clWindowText
              ControlLook.DropDownHeader.Font.Height = -11
              ControlLook.DropDownHeader.Font.Name = 'Tahoma'
              ControlLook.DropDownHeader.Font.Style = []
              ControlLook.DropDownHeader.Visible = True
              ControlLook.DropDownHeader.Buttons = <>
              ControlLook.DropDownFooter.Font.Charset = DEFAULT_CHARSET
              ControlLook.DropDownFooter.Font.Color = clWindowText
              ControlLook.DropDownFooter.Font.Height = -11
              ControlLook.DropDownFooter.Font.Name = 'Tahoma'
              ControlLook.DropDownFooter.Font.Style = []
              ControlLook.DropDownFooter.Visible = True
              ControlLook.DropDownFooter.Buttons = <>
              Filter = <>
              FilterDropDown.Font.Charset = DEFAULT_CHARSET
              FilterDropDown.Font.Color = clWindowText
              FilterDropDown.Font.Height = -11
              FilterDropDown.Font.Name = 'Tahoma'
              FilterDropDown.Font.Style = []
              FilterDropDown.TextChecked = 'Checked'
              FilterDropDown.TextUnChecked = 'Unchecked'
              FilterDropDownClear = '(All)'
              FilterEdit.TypeNames.Strings = (
                'Starts with'
                'Ends with'
                'Contains'
                'Not contains'
                'Equal'
                'Not equal'
                'Larger than'
                'Smaller than'
                'Clear')
              FixedRowHeight = 22
              FixedFont.Charset = DEFAULT_CHARSET
              FixedFont.Color = clWindowText
              FixedFont.Height = -11
              FixedFont.Name = 'Tahoma'
              FixedFont.Style = [fsBold]
              FloatFormat = '%.2f'
              HoverButtons.Buttons = <>
              HoverButtons.Position = hbLeftFromColumnLeft
              HTMLSettings.ImageFolder = 'images'
              HTMLSettings.ImageBaseName = 'img'
              PrintSettings.DateFormat = 'dd/mm/yyyy'
              PrintSettings.Font.Charset = DEFAULT_CHARSET
              PrintSettings.Font.Color = clWindowText
              PrintSettings.Font.Height = -11
              PrintSettings.Font.Name = 'Tahoma'
              PrintSettings.Font.Style = []
              PrintSettings.FixedFont.Charset = DEFAULT_CHARSET
              PrintSettings.FixedFont.Color = clWindowText
              PrintSettings.FixedFont.Height = -11
              PrintSettings.FixedFont.Name = 'Tahoma'
              PrintSettings.FixedFont.Style = []
              PrintSettings.HeaderFont.Charset = DEFAULT_CHARSET
              PrintSettings.HeaderFont.Color = clWindowText
              PrintSettings.HeaderFont.Height = -11
              PrintSettings.HeaderFont.Name = 'Tahoma'
              PrintSettings.HeaderFont.Style = []
              PrintSettings.FooterFont.Charset = DEFAULT_CHARSET
              PrintSettings.FooterFont.Color = clWindowText
              PrintSettings.FooterFont.Height = -11
              PrintSettings.FooterFont.Name = 'Tahoma'
              PrintSettings.FooterFont.Style = []
              PrintSettings.PageNumSep = '/'
              SearchFooter.FindNextCaption = 'Find &next'
              SearchFooter.FindPrevCaption = 'Find &previous'
              SearchFooter.Font.Charset = DEFAULT_CHARSET
              SearchFooter.Font.Color = clWindowText
              SearchFooter.Font.Height = -11
              SearchFooter.Font.Name = 'Tahoma'
              SearchFooter.Font.Style = []
              SearchFooter.HighLightCaption = 'Highlight'
              SearchFooter.HintClose = 'Close'
              SearchFooter.HintFindNext = 'Find next occurrence'
              SearchFooter.HintFindPrev = 'Find previous occurrence'
              SearchFooter.HintHighlight = 'Highlight occurrences'
              SearchFooter.MatchCaseCaption = 'Match case'
              SearchFooter.ResultFormat = '(%d of %d)'
              ShowDesignHelper = False
              SortSettings.DefaultFormat = ssAutomatic
              Version = '8.3.2.4'
              ColWidths = (
                64
                64
                64
                64
                64)
            end
          end
        end
        object btnVirSerial: TBitBtn
          Left = 822
          Top = 154
          Width = 137
          Height = 57
          Caption = 'Virtual Serial'
          TabOrder = 1
          OnClick = btnVirSerialClick
        end
        object pnlSwitch: TAdvPanel
          Left = 626
          Top = 27
          Width = 190
          Height = 206
          Color = clActiveCaption
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = []
          ParentFont = False
          TabOrder = 2
          UseDockManager = True
          Visible = False
          Version = '2.5.7.1'
          CanMove = True
          Caption.Color = clHighlight
          Caption.ColorTo = clNone
          Caption.CloseButton = True
          Caption.Flat = True
          Caption.Font.Charset = ANSI_CHARSET
          Caption.Font.Color = clWhite
          Caption.Font.Height = -13
          Caption.Font.Name = 'Verdana'
          Caption.Font.Style = []
          Caption.Indent = 0
          Caption.ShadeType = stLMetal
          Caption.Shape = csSemiRounded
          Caption.Text = '<B>Switch Simulator</B>'
          Caption.Visible = True
          DoubleBuffered = True
          StatusBar.Font.Charset = DEFAULT_CHARSET
          StatusBar.Font.Color = clWindowText
          StatusBar.Font.Height = -11
          StatusBar.Font.Name = 'Tahoma'
          StatusBar.Font.Style = []
          Text = ''
          FullHeight = 200
          object btnSWNext1: TRzBitBtn
            Left = 4
            Top = 176
            Width = 181
            Caption = 'Next'
            HotTrack = True
            TabOrder = 8
            TabStop = False
            OnClick = btnSWNext1Click
            Glyph.Data = {
              36060000424D3606000000000000360400002800000020000000100000000100
              08000000000000020000520B0000520B00000001000000000000000000003300
              00006600000099000000CC000000FF0000000033000033330000663300009933
              0000CC330000FF33000000660000336600006666000099660000CC660000FF66
              000000990000339900006699000099990000CC990000FF99000000CC000033CC
              000066CC000099CC0000CCCC0000FFCC000000FF000033FF000066FF000099FF
              0000CCFF0000FFFF000000003300330033006600330099003300CC003300FF00
              330000333300333333006633330099333300CC333300FF333300006633003366
              33006666330099663300CC663300FF6633000099330033993300669933009999
              3300CC993300FF99330000CC330033CC330066CC330099CC3300CCCC3300FFCC
              330000FF330033FF330066FF330099FF3300CCFF3300FFFF3300000066003300
              66006600660099006600CC006600FF0066000033660033336600663366009933
              6600CC336600FF33660000666600336666006666660099666600CC666600FF66
              660000996600339966006699660099996600CC996600FF99660000CC660033CC
              660066CC660099CC6600CCCC6600FFCC660000FF660033FF660066FF660099FF
              6600CCFF6600FFFF660000009900330099006600990099009900CC009900FF00
              990000339900333399006633990099339900CC339900FF339900006699003366
              99006666990099669900CC669900FF6699000099990033999900669999009999
              9900CC999900FF99990000CC990033CC990066CC990099CC9900CCCC9900FFCC
              990000FF990033FF990066FF990099FF9900CCFF9900FFFF99000000CC003300
              CC006600CC009900CC00CC00CC00FF00CC000033CC003333CC006633CC009933
              CC00CC33CC00FF33CC000066CC003366CC006666CC009966CC00CC66CC00FF66
              CC000099CC003399CC006699CC009999CC00CC99CC00FF99CC0000CCCC0033CC
              CC0066CCCC0099CCCC00CCCCCC00FFCCCC0000FFCC0033FFCC0066FFCC0099FF
              CC00CCFFCC00FFFFCC000000FF003300FF006600FF009900FF00CC00FF00FF00
              FF000033FF003333FF006633FF009933FF00CC33FF00FF33FF000066FF003366
              FF006666FF009966FF00CC66FF00FF66FF000099FF003399FF006699FF009999
              FF00CC99FF00FF99FF0000CCFF0033CCFF0066CCFF0099CCFF00CCCCFF00FFCC
              FF0000FFFF0033FFFF0066FFFF0099FFFF00CCFFFF00FFFFFF00000080000080
              000000808000800000008000800080800000C0C0C00080808000191919004C4C
              4C00B2B2B200E5E5E500C8AC2800E0CC6600F2EABF00B59B2400D8E9EC009933
              6600D075A300ECC6D900646F710099A8AC00E2EFF10000000000000000000000
              0000000000000000000000000000000000000000000000000000000000000000
              0000000000000000000000000000000000000000000000000000E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E809090909E8E8
              E809090909E8E8E8E8E881818181E8E8E881818181E8E8E8E8E80910101009E8
              E80910101009E8E8E8E881ACACAC81E8E881ACACAC81E8E8E8E8E80910101009
              E8E80910101009E8E8E8E881ACACAC81E8E881ACACAC81E8E8E8E8E809101010
              09E8E80910101009E8E8E8E881ACACAC81E8E881ACACAC81E8E8E8E8E8091010
              1009E8E80910101009E8E8E8E881ACACAC81E8E881ACACAC81E8E8E8E8E80910
              101009E8E80910101009E8E8E8E881ACACAC81E8E881ACACAC81E8E8E8E80910
              101009E8E80910101009E8E8E8E881ACACAC81E8E881ACACAC81E8E8E8091010
              1009E8E80910101009E8E8E8E881ACACAC81E8E881ACACAC81E8E8E809101010
              09E8E80910101009E8E8E8E881ACACAC81E8E881ACACAC81E8E8E80910101009
              E8E80910101009E8E8E8E881ACACAC81E8E881ACACAC81E8E8E80910101009E8
              E80910101009E8E8E8E881ACACAC81E8E881ACACAC81E8E8E8E809090909E8E8
              E809090909E8E8E8E8E881818181E8E8E881818181E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8}
            NumGlyphs = 2
          end
          object btnSWCancel1: TRzBitBtn
            Tag = 1
            Left = 98
            Top = 30
            Width = 87
            Caption = 'ESC'
            HotTrack = True
            TabOrder = 6
            TabStop = False
            OnClick = btnSWCancel1Click
            Glyph.Data = {
              36060000424D3606000000000000360400002800000020000000100000000100
              08000000000000020000E30E0000E30E00000001000000000000000000003300
              00006600000099000000CC000000FF0000000033000033330000663300009933
              0000CC330000FF33000000660000336600006666000099660000CC660000FF66
              000000990000339900006699000099990000CC990000FF99000000CC000033CC
              000066CC000099CC0000CCCC0000FFCC000000FF000033FF000066FF000099FF
              0000CCFF0000FFFF000000003300330033006600330099003300CC003300FF00
              330000333300333333006633330099333300CC333300FF333300006633003366
              33006666330099663300CC663300FF6633000099330033993300669933009999
              3300CC993300FF99330000CC330033CC330066CC330099CC3300CCCC3300FFCC
              330000FF330033FF330066FF330099FF3300CCFF3300FFFF3300000066003300
              66006600660099006600CC006600FF0066000033660033336600663366009933
              6600CC336600FF33660000666600336666006666660099666600CC666600FF66
              660000996600339966006699660099996600CC996600FF99660000CC660033CC
              660066CC660099CC6600CCCC6600FFCC660000FF660033FF660066FF660099FF
              6600CCFF6600FFFF660000009900330099006600990099009900CC009900FF00
              990000339900333399006633990099339900CC339900FF339900006699003366
              99006666990099669900CC669900FF6699000099990033999900669999009999
              9900CC999900FF99990000CC990033CC990066CC990099CC9900CCCC9900FFCC
              990000FF990033FF990066FF990099FF9900CCFF9900FFFF99000000CC003300
              CC006600CC009900CC00CC00CC00FF00CC000033CC003333CC006633CC009933
              CC00CC33CC00FF33CC000066CC003366CC006666CC009966CC00CC66CC00FF66
              CC000099CC003399CC006699CC009999CC00CC99CC00FF99CC0000CCCC0033CC
              CC0066CCCC0099CCCC00CCCCCC00FFCCCC0000FFCC0033FFCC0066FFCC0099FF
              CC00CCFFCC00FFFFCC000000FF003300FF006600FF009900FF00CC00FF00FF00
              FF000033FF003333FF006633FF009933FF00CC33FF00FF33FF000066FF003366
              FF006666FF009966FF00CC66FF00FF66FF000099FF003399FF006699FF009999
              FF00CC99FF00FF99FF0000CCFF0033CCFF0066CCFF0099CCFF00CCCCFF00FFCC
              FF0000FFFF0033FFFF0066FFFF0099FFFF00CCFFFF00FFFFFF00000080000080
              000000808000800000008000800080800000C0C0C00080808000191919004C4C
              4C00B2B2B200E5E5E500C8AC2800E0CC6600F2EABF00B59B2400D8E9EC009933
              6600D075A300ECC6D900646F710099A8AC00E2EFF10000000000000000000000
              0000000000000000000000000000000000000000000000000000000000000000
              0000000000000000000000000000000000000000000000000000E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E86C6C6C
              6C6C6C6C6C6C6CE8E8E8E8E8E881818181818181818181E8E8E8E8E86C909090
              90906C906C6C6C6CE8E8E8E881E2E2E2E2E281E281818181E8E8E8E86CB49090
              9090906C906C6C6CE8E8E8E881ACE2E2E2E2E281E2818181E8E8E8E86C90B490
              909090906C906C6CE8E8E8E881E2ACE2E2E2E2E281E28181E8E8E8E86CB490B4
              90909090906C906CE8E8E8E881ACE2ACE2E2E2E2E281E281E8E8E8E86CB4B490
              B490909090906C6CE8E8E8E881ACACE2ACE2E2E2E2E28181E8E8E8E86CC9B4B4
              90B490909090906CE8E8E8E881E3ACACE2ACE2E2E2E2E281E8E8E8E86CC9C9B4
              B490B4909090906CE8E8E8E881E3E3ACACE2ACE2E2E2E281E8E8E8E8E86C6C6C
              6C6C6C6C6C6C6CE8E8E8E8E8E881818181818181818181E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8}
            NumGlyphs = 2
          end
          object RzBitBtn2: TRzBitBtn
            Left = 98
            Top = 63
            Width = 87
            Caption = 'Back'
            HotTrack = True
            TabOrder = 7
            TabStop = False
            OnClick = RzBitBtn2Click
            Glyph.Data = {
              36060000424D3606000000000000360400002800000020000000100000000100
              08000000000000020000630B0000630B00000001000000000000000000003300
              00006600000099000000CC000000FF0000000033000033330000663300009933
              0000CC330000FF33000000660000336600006666000099660000CC660000FF66
              000000990000339900006699000099990000CC990000FF99000000CC000033CC
              000066CC000099CC0000CCCC0000FFCC000000FF000033FF000066FF000099FF
              0000CCFF0000FFFF000000003300330033006600330099003300CC003300FF00
              330000333300333333006633330099333300CC333300FF333300006633003366
              33006666330099663300CC663300FF6633000099330033993300669933009999
              3300CC993300FF99330000CC330033CC330066CC330099CC3300CCCC3300FFCC
              330000FF330033FF330066FF330099FF3300CCFF3300FFFF3300000066003300
              66006600660099006600CC006600FF0066000033660033336600663366009933
              6600CC336600FF33660000666600336666006666660099666600CC666600FF66
              660000996600339966006699660099996600CC996600FF99660000CC660033CC
              660066CC660099CC6600CCCC6600FFCC660000FF660033FF660066FF660099FF
              6600CCFF6600FFFF660000009900330099006600990099009900CC009900FF00
              990000339900333399006633990099339900CC339900FF339900006699003366
              99006666990099669900CC669900FF6699000099990033999900669999009999
              9900CC999900FF99990000CC990033CC990066CC990099CC9900CCCC9900FFCC
              990000FF990033FF990066FF990099FF9900CCFF9900FFFF99000000CC003300
              CC006600CC009900CC00CC00CC00FF00CC000033CC003333CC006633CC009933
              CC00CC33CC00FF33CC000066CC003366CC006666CC009966CC00CC66CC00FF66
              CC000099CC003399CC006699CC009999CC00CC99CC00FF99CC0000CCCC0033CC
              CC0066CCCC0099CCCC00CCCCCC00FFCCCC0000FFCC0033FFCC0066FFCC0099FF
              CC00CCFFCC00FFFFCC000000FF003300FF006600FF009900FF00CC00FF00FF00
              FF000033FF003333FF006633FF009933FF00CC33FF00FF33FF000066FF003366
              FF006666FF009966FF00CC66FF00FF66FF000099FF003399FF006699FF009999
              FF00CC99FF00FF99FF0000CCFF0033CCFF0066CCFF0099CCFF00CCCCFF00FFCC
              FF0000FFFF0033FFFF0066FFFF0099FFFF00CCFFFF00FFFFFF00000080000080
              000000808000800000008000800080800000C0C0C00080808000191919004C4C
              4C00B2B2B200E5E5E500C8AC2800E0CC6600F2EABF00B59B2400D8E9EC009933
              6600D075A300ECC6D900646F710099A8AC00E2EFF10000000000000000000000
              0000000000000000000000000000000000000000000000000000000000000000
              0000000000000000000000000000000000000000000000000000E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E85E09
              095EE8E8E8E8E8E8E8E8E8E8E8E8E28181E2E8E8E8E8E8E8E8E8E8E8E8090910
              1009E8E8E8E8E8E8E8E8E8E8E88181ACAC81E8E8E8E8E8E8E8E8E8E809101009
              095EE8E8E8E8E8E8E8E8E8E881ACAC8181E2E8E8E8E8E8E8E8E8E85E0910095E
              E8E809090909090909E8E8E281AC81E2E8E881818181818181E8E80910095EE8
              E8E809101010101009E8E881AC81E2E8E8E881ACACACACAC81E8E8091009E8E8
              E8E8E8091010101009E8E881AC81E8E8E8E8E881ACACACAC81E8E80910095EE8
              E8E8E85E0910101009E8E881AC81E2E8E8E8E8E281ACACAC81E8E85E0910095E
              E85E09091009101009E8E8E281AC81E2E8E28181AC81ACAC81E8E8E809101009
              09091010095E091009E8E8E881ACAC818181ACAC81E281AC81E8E8E8E8090910
              10100909E8E8E80909E8E8E8E88181ACACAC8181E8E8E88181E8E8E8E8E85E09
              09095EE8E8E8E8E8E8E8E8E8E8E8E2818181E2E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8}
            NumGlyphs = 2
          end
          object btnAuto: TRzBitBtn
            Tag = 1
            Left = 5
            Top = 30
            Width = 87
            HotTrack = True
            TabOrder = 0
            TabStop = False
            OnClick = btnAutoClick
            Glyph.Data = {
              36060000424D3606000000000000360400002800000020000000100000000100
              08000000000000020000430C0000430C00000001000000000000000000003300
              00006600000099000000CC000000FF0000000033000033330000663300009933
              0000CC330000FF33000000660000336600006666000099660000CC660000FF66
              000000990000339900006699000099990000CC990000FF99000000CC000033CC
              000066CC000099CC0000CCCC0000FFCC000000FF000033FF000066FF000099FF
              0000CCFF0000FFFF000000003300330033006600330099003300CC003300FF00
              330000333300333333006633330099333300CC333300FF333300006633003366
              33006666330099663300CC663300FF6633000099330033993300669933009999
              3300CC993300FF99330000CC330033CC330066CC330099CC3300CCCC3300FFCC
              330000FF330033FF330066FF330099FF3300CCFF3300FFFF3300000066003300
              66006600660099006600CC006600FF0066000033660033336600663366009933
              6600CC336600FF33660000666600336666006666660099666600CC666600FF66
              660000996600339966006699660099996600CC996600FF99660000CC660033CC
              660066CC660099CC6600CCCC6600FFCC660000FF660033FF660066FF660099FF
              6600CCFF6600FFFF660000009900330099006600990099009900CC009900FF00
              990000339900333399006633990099339900CC339900FF339900006699003366
              99006666990099669900CC669900FF6699000099990033999900669999009999
              9900CC999900FF99990000CC990033CC990066CC990099CC9900CCCC9900FFCC
              990000FF990033FF990066FF990099FF9900CCFF9900FFFF99000000CC003300
              CC006600CC009900CC00CC00CC00FF00CC000033CC003333CC006633CC009933
              CC00CC33CC00FF33CC000066CC003366CC006666CC009966CC00CC66CC00FF66
              CC000099CC003399CC006699CC009999CC00CC99CC00FF99CC0000CCCC0033CC
              CC0066CCCC0099CCCC00CCCCCC00FFCCCC0000FFCC0033FFCC0066FFCC0099FF
              CC00CCFFCC00FFFFCC000000FF003300FF006600FF009900FF00CC00FF00FF00
              FF000033FF003333FF006633FF009933FF00CC33FF00FF33FF000066FF003366
              FF006666FF009966FF00CC66FF00FF66FF000099FF003399FF006699FF009999
              FF00CC99FF00FF99FF0000CCFF0033CCFF0066CCFF0099CCFF00CCCCFF00FFCC
              FF0000FFFF0033FFFF0066FFFF0099FFFF00CCFFFF00FFFFFF00000080000080
              000000808000800000008000800080800000C0C0C00080808000191919004C4C
              4C00B2B2B200E5E5E500C8AC2800E0CC6600F2EABF00B59B2400D8E9EC009933
              6600D075A300ECC6D900646F710099A8AC00E2EFF10000000000000000000000
              0000000000000000000000000000000000000000000000000000000000000000
              0000000000000000000000000000000000000000000000000000E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8030303
              03030303030303E8E8E8E8E8E881818181818181818181E8E8E8E8E803040404
              0404030403030303E8E8E8E881E2E2E2E2E281E281818181E8E8E8E803050404
              0404040304030303E8E8E8E881ACE2E2E2E2E281E2818181E8E8E8E803040504
              0404040403040303E8E8E8E881E2ACE2E2E2E2E281E28181E8E8E8E803050405
              0404040404030403E8E8E8E881ACE2ACE2E2E2E2E281E281E8E8E8E803050504
              0504040404040303E8E8E8E881ACACE2ACE2E2E2E2E28181E8E8E8E8035F0505
              0405040404040403E8E8E8E881E3ACACE2ACE2E2E2E2E281E8E8E8E8035F5F05
              0504050404040403E8E8E8E881E3E3ACACE2ACE2E2E2E281E8E8E8E8E8030303
              03030303030303E8E8E8E8E8E881818181818181818181E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8}
            NumGlyphs = 2
          end
          object btnCh4: TRzBitBtn
            Tag = 1
            Left = 5
            Top = 139
            Width = 87
            HotTrack = True
            TabOrder = 3
            TabStop = False
            Glyph.Data = {
              36060000424D3606000000000000360400002800000020000000100000000100
              08000000000000020000D30B0000D30B00000001000000000000000000003300
              00006600000099000000CC000000FF0000000033000033330000663300009933
              0000CC330000FF33000000660000336600006666000099660000CC660000FF66
              000000990000339900006699000099990000CC990000FF99000000CC000033CC
              000066CC000099CC0000CCCC0000FFCC000000FF000033FF000066FF000099FF
              0000CCFF0000FFFF000000003300330033006600330099003300CC003300FF00
              330000333300333333006633330099333300CC333300FF333300006633003366
              33006666330099663300CC663300FF6633000099330033993300669933009999
              3300CC993300FF99330000CC330033CC330066CC330099CC3300CCCC3300FFCC
              330000FF330033FF330066FF330099FF3300CCFF3300FFFF3300000066003300
              66006600660099006600CC006600FF0066000033660033336600663366009933
              6600CC336600FF33660000666600336666006666660099666600CC666600FF66
              660000996600339966006699660099996600CC996600FF99660000CC660033CC
              660066CC660099CC6600CCCC6600FFCC660000FF660033FF660066FF660099FF
              6600CCFF6600FFFF660000009900330099006600990099009900CC009900FF00
              990000339900333399006633990099339900CC339900FF339900006699003366
              99006666990099669900CC669900FF6699000099990033999900669999009999
              9900CC999900FF99990000CC990033CC990066CC990099CC9900CCCC9900FFCC
              990000FF990033FF990066FF990099FF9900CCFF9900FFFF99000000CC003300
              CC006600CC009900CC00CC00CC00FF00CC000033CC003333CC006633CC009933
              CC00CC33CC00FF33CC000066CC003366CC006666CC009966CC00CC66CC00FF66
              CC000099CC003399CC006699CC009999CC00CC99CC00FF99CC0000CCCC0033CC
              CC0066CCCC0099CCCC00CCCCCC00FFCCCC0000FFCC0033FFCC0066FFCC0099FF
              CC00CCFFCC00FFFFCC000000FF003300FF006600FF009900FF00CC00FF00FF00
              FF000033FF003333FF006633FF009933FF00CC33FF00FF33FF000066FF003366
              FF006666FF009966FF00CC66FF00FF66FF000099FF003399FF006699FF009999
              FF00CC99FF00FF99FF0000CCFF0033CCFF0066CCFF0099CCFF00CCCCFF00FFCC
              FF0000FFFF0033FFFF0066FFFF0099FFFF00CCFFFF00FFFFFF00000080000080
              000000808000800000008000800080800000C0C0C00080808000191919004C4C
              4C00B2B2B200E5E5E500C8AC2800E0CC6600F2EABF00B59B2400D8E9EC009933
              6600D075A300ECC6D900646F710099A8AC00E2EFF10000000000000000000000
              0000000000000000000000000000000000000000000000000000000000000000
              0000000000000000000000000000000000000000000000000000E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8818181
              81818181818181E8E8E8E8E8E881818181818181818181E8E8E8E8E881E2E2E2
              E2E281E281818181E8E8E8E881E2E2E2E2E281E281818181E8E8E8E881ACE2E2
              E2E2E281E2818181E8E8E8E881ACE2E2E2E2E281E2818181E8E8E8E881E2ACE2
              E2E2E2E281E28181E8E8E8E881E2ACE2E2E2E2E281E28181E8E8E8E881ACE2AC
              E2E2E2E2E281E281E8E8E8E881ACE2ACE2E2E2E2E281E281E8E8E8E881ACACE2
              ACE2E2E2E2E28181E8E8E8E881ACACE2ACE2E2E2E2E28181E8E8E8E881E3ACAC
              E2ACE2E2E2E2E281E8E8E8E881E3ACACE2ACE2E2E2E2E281E8E8E8E881E3E3AC
              ACE2ACE2E2E2E281E8E8E8E881E3E3ACACE2ACE2E2E2E281E8E8E8E8E8818181
              81818181818181E8E8E8E8E8E881818181818181818181E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8}
            NumGlyphs = 2
          end
          object btnRepeat: TRzBitBtn
            Tag = 1
            Left = 5
            Top = 63
            Width = 87
            HotTrack = True
            TabOrder = 2
            TabStop = False
            OnClick = btnRepeatClick
            Glyph.Data = {
              36060000424D3606000000000000360400002800000020000000100000000100
              08000000000000020000E30E0000E30E00000001000000000000000000003300
              00006600000099000000CC000000FF0000000033000033330000663300009933
              0000CC330000FF33000000660000336600006666000099660000CC660000FF66
              000000990000339900006699000099990000CC990000FF99000000CC000033CC
              000066CC000099CC0000CCCC0000FFCC000000FF000033FF000066FF000099FF
              0000CCFF0000FFFF000000003300330033006600330099003300CC003300FF00
              330000333300333333006633330099333300CC333300FF333300006633003366
              33006666330099663300CC663300FF6633000099330033993300669933009999
              3300CC993300FF99330000CC330033CC330066CC330099CC3300CCCC3300FFCC
              330000FF330033FF330066FF330099FF3300CCFF3300FFFF3300000066003300
              66006600660099006600CC006600FF0066000033660033336600663366009933
              6600CC336600FF33660000666600336666006666660099666600CC666600FF66
              660000996600339966006699660099996600CC996600FF99660000CC660033CC
              660066CC660099CC6600CCCC6600FFCC660000FF660033FF660066FF660099FF
              6600CCFF6600FFFF660000009900330099006600990099009900CC009900FF00
              990000339900333399006633990099339900CC339900FF339900006699003366
              99006666990099669900CC669900FF6699000099990033999900669999009999
              9900CC999900FF99990000CC990033CC990066CC990099CC9900CCCC9900FFCC
              990000FF990033FF990066FF990099FF9900CCFF9900FFFF99000000CC003300
              CC006600CC009900CC00CC00CC00FF00CC000033CC003333CC006633CC009933
              CC00CC33CC00FF33CC000066CC003366CC006666CC009966CC00CC66CC00FF66
              CC000099CC003399CC006699CC009999CC00CC99CC00FF99CC0000CCCC0033CC
              CC0066CCCC0099CCCC00CCCCCC00FFCCCC0000FFCC0033FFCC0066FFCC0099FF
              CC00CCFFCC00FFFFCC000000FF003300FF006600FF009900FF00CC00FF00FF00
              FF000033FF003333FF006633FF009933FF00CC33FF00FF33FF000066FF003366
              FF006666FF009966FF00CC66FF00FF66FF000099FF003399FF006699FF009999
              FF00CC99FF00FF99FF0000CCFF0033CCFF0066CCFF0099CCFF00CCCCFF00FFCC
              FF0000FFFF0033FFFF0066FFFF0099FFFF00CCFFFF00FFFFFF00000080000080
              000000808000800000008000800080800000C0C0C00080808000191919004C4C
              4C00B2B2B200E5E5E500C8AC2800E0CC6600F2EABF00B59B2400D8E9EC009933
              6600D075A300ECC6D900646F710099A8AC00E2EFF10000000000000000000000
              0000000000000000000000000000000000000000000000000000000000000000
              0000000000000000000000000000000000000000000000000000E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E89C9C9C
              9C9C9C9C9C9C9CE8E8E8E8E8E881818181818181818181E8E8E8E8E89CC6C6C6
              C6C69CC69C9C9C9CE8E8E8E881E2E2E2E2E281E281818181E8E8E8E89CCCC6C6
              C6C6C69CC69C9C9CE8E8E8E881ACE2E2E2E2E281E2818181E8E8E8E89CC6CCC6
              C6C6C6C69CC69C9CE8E8E8E881E2ACE2E2E2E2E281E28181E8E8E8E89CCCC6CC
              C6C6C6C6C69CC69CE8E8E8E881ACE2ACE2E2E2E2E281E281E8E8E8E89CCCCCC6
              CCC6C6C6C6C69C9CE8E8E8E881ACACE2ACE2E2E2E2E28181E8E8E8E89CCFCCCC
              C6CCC6C6C6C6C69CE8E8E8E881E3ACACE2ACE2E2E2E2E281E8E8E8E89CCFCFCC
              CCC6CCC6C6C6C69CE8E8E8E881E3E3ACACE2ACE2E2E2E281E8E8E8E8E89C9C9C
              9C9C9C9C9C9C9CE8E8E8E8E8E881818181818181818181E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8}
            NumGlyphs = 2
          end
          object btnCh2: TRzBitBtn
            Tag = 1
            Left = 98
            Top = 138
            Width = 87
            HotTrack = True
            TabOrder = 1
            TabStop = False
            Glyph.Data = {
              36060000424D3606000000000000360400002800000020000000100000000100
              08000000000000020000D30B0000D30B00000001000000000000000000003300
              00006600000099000000CC000000FF0000000033000033330000663300009933
              0000CC330000FF33000000660000336600006666000099660000CC660000FF66
              000000990000339900006699000099990000CC990000FF99000000CC000033CC
              000066CC000099CC0000CCCC0000FFCC000000FF000033FF000066FF000099FF
              0000CCFF0000FFFF000000003300330033006600330099003300CC003300FF00
              330000333300333333006633330099333300CC333300FF333300006633003366
              33006666330099663300CC663300FF6633000099330033993300669933009999
              3300CC993300FF99330000CC330033CC330066CC330099CC3300CCCC3300FFCC
              330000FF330033FF330066FF330099FF3300CCFF3300FFFF3300000066003300
              66006600660099006600CC006600FF0066000033660033336600663366009933
              6600CC336600FF33660000666600336666006666660099666600CC666600FF66
              660000996600339966006699660099996600CC996600FF99660000CC660033CC
              660066CC660099CC6600CCCC6600FFCC660000FF660033FF660066FF660099FF
              6600CCFF6600FFFF660000009900330099006600990099009900CC009900FF00
              990000339900333399006633990099339900CC339900FF339900006699003366
              99006666990099669900CC669900FF6699000099990033999900669999009999
              9900CC999900FF99990000CC990033CC990066CC990099CC9900CCCC9900FFCC
              990000FF990033FF990066FF990099FF9900CCFF9900FFFF99000000CC003300
              CC006600CC009900CC00CC00CC00FF00CC000033CC003333CC006633CC009933
              CC00CC33CC00FF33CC000066CC003366CC006666CC009966CC00CC66CC00FF66
              CC000099CC003399CC006699CC009999CC00CC99CC00FF99CC0000CCCC0033CC
              CC0066CCCC0099CCCC00CCCCCC00FFCCCC0000FFCC0033FFCC0066FFCC0099FF
              CC00CCFFCC00FFFFCC000000FF003300FF006600FF009900FF00CC00FF00FF00
              FF000033FF003333FF006633FF009933FF00CC33FF00FF33FF000066FF003366
              FF006666FF009966FF00CC66FF00FF66FF000099FF003399FF006699FF009999
              FF00CC99FF00FF99FF0000CCFF0033CCFF0066CCFF0099CCFF00CCCCFF00FFCC
              FF0000FFFF0033FFFF0066FFFF0099FFFF00CCFFFF00FFFFFF00000080000080
              000000808000800000008000800080800000C0C0C00080808000191919004C4C
              4C00B2B2B200E5E5E500C8AC2800E0CC6600F2EABF00B59B2400D8E9EC009933
              6600D075A300ECC6D900646F710099A8AC00E2EFF10000000000000000000000
              0000000000000000000000000000000000000000000000000000000000000000
              0000000000000000000000000000000000000000000000000000E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8818181
              81818181818181E8E8E8E8E8E881818181818181818181E8E8E8E8E881E2E2E2
              E2E281E281818181E8E8E8E881E2E2E2E2E281E281818181E8E8E8E881ACE2E2
              E2E2E281E2818181E8E8E8E881ACE2E2E2E2E281E2818181E8E8E8E881E2ACE2
              E2E2E2E281E28181E8E8E8E881E2ACE2E2E2E2E281E28181E8E8E8E881ACE2AC
              E2E2E2E2E281E281E8E8E8E881ACE2ACE2E2E2E2E281E281E8E8E8E881ACACE2
              ACE2E2E2E2E28181E8E8E8E881ACACE2ACE2E2E2E2E28181E8E8E8E881E3ACAC
              E2ACE2E2E2E2E281E8E8E8E881E3ACACE2ACE2E2E2E2E281E8E8E8E881E3E3AC
              ACE2ACE2E2E2E281E8E8E8E881E3E3ACACE2ACE2E2E2E281E8E8E8E8E8818181
              81818181818181E8E8E8E8E8E881818181818181818181E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8}
            NumGlyphs = 2
          end
          object RzBitBtn7: TRzBitBtn
            Tag = 1
            Left = 5
            Top = 103
            Width = 87
            HotTrack = True
            TabOrder = 4
            TabStop = False
            Glyph.Data = {
              36060000424D3606000000000000360400002800000020000000100000000100
              08000000000000020000D30B0000D30B00000001000000000000000000003300
              00006600000099000000CC000000FF0000000033000033330000663300009933
              0000CC330000FF33000000660000336600006666000099660000CC660000FF66
              000000990000339900006699000099990000CC990000FF99000000CC000033CC
              000066CC000099CC0000CCCC0000FFCC000000FF000033FF000066FF000099FF
              0000CCFF0000FFFF000000003300330033006600330099003300CC003300FF00
              330000333300333333006633330099333300CC333300FF333300006633003366
              33006666330099663300CC663300FF6633000099330033993300669933009999
              3300CC993300FF99330000CC330033CC330066CC330099CC3300CCCC3300FFCC
              330000FF330033FF330066FF330099FF3300CCFF3300FFFF3300000066003300
              66006600660099006600CC006600FF0066000033660033336600663366009933
              6600CC336600FF33660000666600336666006666660099666600CC666600FF66
              660000996600339966006699660099996600CC996600FF99660000CC660033CC
              660066CC660099CC6600CCCC6600FFCC660000FF660033FF660066FF660099FF
              6600CCFF6600FFFF660000009900330099006600990099009900CC009900FF00
              990000339900333399006633990099339900CC339900FF339900006699003366
              99006666990099669900CC669900FF6699000099990033999900669999009999
              9900CC999900FF99990000CC990033CC990066CC990099CC9900CCCC9900FFCC
              990000FF990033FF990066FF990099FF9900CCFF9900FFFF99000000CC003300
              CC006600CC009900CC00CC00CC00FF00CC000033CC003333CC006633CC009933
              CC00CC33CC00FF33CC000066CC003366CC006666CC009966CC00CC66CC00FF66
              CC000099CC003399CC006699CC009999CC00CC99CC00FF99CC0000CCCC0033CC
              CC0066CCCC0099CCCC00CCCCCC00FFCCCC0000FFCC0033FFCC0066FFCC0099FF
              CC00CCFFCC00FFFFCC000000FF003300FF006600FF009900FF00CC00FF00FF00
              FF000033FF003333FF006633FF009933FF00CC33FF00FF33FF000066FF003366
              FF006666FF009966FF00CC66FF00FF66FF000099FF003399FF006699FF009999
              FF00CC99FF00FF99FF0000CCFF0033CCFF0066CCFF0099CCFF00CCCCFF00FFCC
              FF0000FFFF0033FFFF0066FFFF0099FFFF00CCFFFF00FFFFFF00000080000080
              000000808000800000008000800080800000C0C0C00080808000191919004C4C
              4C00B2B2B200E5E5E500C8AC2800E0CC6600F2EABF00B59B2400D8E9EC009933
              6600D075A300ECC6D900646F710099A8AC00E2EFF10000000000000000000000
              0000000000000000000000000000000000000000000000000000000000000000
              0000000000000000000000000000000000000000000000000000E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8818181
              81818181818181E8E8E8E8E8E881818181818181818181E8E8E8E8E881E2E2E2
              E2E281E281818181E8E8E8E881E2E2E2E2E281E281818181E8E8E8E881ACE2E2
              E2E2E281E2818181E8E8E8E881ACE2E2E2E2E281E2818181E8E8E8E881E2ACE2
              E2E2E2E281E28181E8E8E8E881E2ACE2E2E2E2E281E28181E8E8E8E881ACE2AC
              E2E2E2E2E281E281E8E8E8E881ACE2ACE2E2E2E2E281E281E8E8E8E881ACACE2
              ACE2E2E2E2E28181E8E8E8E881ACACE2ACE2E2E2E2E28181E8E8E8E881E3ACAC
              E2ACE2E2E2E2E281E8E8E8E881E3ACACE2ACE2E2E2E2E281E8E8E8E881E3E3AC
              ACE2ACE2E2E2E281E8E8E8E881E3E3ACACE2ACE2E2E2E281E8E8E8E8E8818181
              81818181818181E8E8E8E8E8E881818181818181818181E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8}
            NumGlyphs = 2
          end
          object RzBitBtn8: TRzBitBtn
            Tag = 1
            Left = 98
            Top = 103
            Width = 87
            HotTrack = True
            TabOrder = 5
            TabStop = False
            Glyph.Data = {
              36060000424D3606000000000000360400002800000020000000100000000100
              08000000000000020000D30B0000D30B00000001000000000000000000003300
              00006600000099000000CC000000FF0000000033000033330000663300009933
              0000CC330000FF33000000660000336600006666000099660000CC660000FF66
              000000990000339900006699000099990000CC990000FF99000000CC000033CC
              000066CC000099CC0000CCCC0000FFCC000000FF000033FF000066FF000099FF
              0000CCFF0000FFFF000000003300330033006600330099003300CC003300FF00
              330000333300333333006633330099333300CC333300FF333300006633003366
              33006666330099663300CC663300FF6633000099330033993300669933009999
              3300CC993300FF99330000CC330033CC330066CC330099CC3300CCCC3300FFCC
              330000FF330033FF330066FF330099FF3300CCFF3300FFFF3300000066003300
              66006600660099006600CC006600FF0066000033660033336600663366009933
              6600CC336600FF33660000666600336666006666660099666600CC666600FF66
              660000996600339966006699660099996600CC996600FF99660000CC660033CC
              660066CC660099CC6600CCCC6600FFCC660000FF660033FF660066FF660099FF
              6600CCFF6600FFFF660000009900330099006600990099009900CC009900FF00
              990000339900333399006633990099339900CC339900FF339900006699003366
              99006666990099669900CC669900FF6699000099990033999900669999009999
              9900CC999900FF99990000CC990033CC990066CC990099CC9900CCCC9900FFCC
              990000FF990033FF990066FF990099FF9900CCFF9900FFFF99000000CC003300
              CC006600CC009900CC00CC00CC00FF00CC000033CC003333CC006633CC009933
              CC00CC33CC00FF33CC000066CC003366CC006666CC009966CC00CC66CC00FF66
              CC000099CC003399CC006699CC009999CC00CC99CC00FF99CC0000CCCC0033CC
              CC0066CCCC0099CCCC00CCCCCC00FFCCCC0000FFCC0033FFCC0066FFCC0099FF
              CC00CCFFCC00FFFFCC000000FF003300FF006600FF009900FF00CC00FF00FF00
              FF000033FF003333FF006633FF009933FF00CC33FF00FF33FF000066FF003366
              FF006666FF009966FF00CC66FF00FF66FF000099FF003399FF006699FF009999
              FF00CC99FF00FF99FF0000CCFF0033CCFF0066CCFF0099CCFF00CCCCFF00FFCC
              FF0000FFFF0033FFFF0066FFFF0099FFFF00CCFFFF00FFFFFF00000080000080
              000000808000800000008000800080800000C0C0C00080808000191919004C4C
              4C00B2B2B200E5E5E500C8AC2800E0CC6600F2EABF00B59B2400D8E9EC009933
              6600D075A300ECC6D900646F710099A8AC00E2EFF10000000000000000000000
              0000000000000000000000000000000000000000000000000000000000000000
              0000000000000000000000000000000000000000000000000000E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8818181
              81818181818181E8E8E8E8E8E881818181818181818181E8E8E8E8E881E2E2E2
              E2E281E281818181E8E8E8E881E2E2E2E2E281E281818181E8E8E8E881ACE2E2
              E2E2E281E2818181E8E8E8E881ACE2E2E2E2E281E2818181E8E8E8E881E2ACE2
              E2E2E2E281E28181E8E8E8E881E2ACE2E2E2E2E281E28181E8E8E8E881ACE2AC
              E2E2E2E2E281E281E8E8E8E881ACE2ACE2E2E2E2E281E281E8E8E8E881ACACE2
              ACE2E2E2E2E28181E8E8E8E881ACACE2ACE2E2E2E2E28181E8E8E8E881E3ACAC
              E2ACE2E2E2E2E281E8E8E8E881E3ACACE2ACE2E2E2E2E281E8E8E8E881E3E3AC
              ACE2ACE2E2E2E281E8E8E8E881E3E3ACACE2ACE2E2E2E281E8E8E8E8E8818181
              81818181818181E8E8E8E8E8E881818181818181818181E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8
              E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8E8}
            NumGlyphs = 2
          end
        end
      end
    end
    object TabSheet1: TRzTabSheet
      Caption = 'DATA VIEWER'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -13
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
      ExplicitLeft = 0
      ExplicitTop = 0
      ExplicitWidth = 0
      ExplicitHeight = 0
      object pgcDataViewer: TPageControl
        Left = 0
        Top = 0
        Width = 1429
        Height = 892
        Align = alClient
        TabOrder = 0
      end
      object gridTemp: TAdvStringGrid
        Left = 816
        Top = 324
        Width = 712
        Height = 406
        Cursor = crDefault
        ColCount = 60
        Ctl3D = True
        DrawingStyle = gdsClassic
        RowCount = 30
        ParentCtl3D = False
        ScrollBars = ssBoth
        TabOrder = 1
        Visible = False
        HoverRowCells = [hcNormal, hcSelected]
        ActiveCellFont.Charset = DEFAULT_CHARSET
        ActiveCellFont.Color = clWindowText
        ActiveCellFont.Height = -11
        ActiveCellFont.Name = 'Tahoma'
        ActiveCellFont.Style = [fsBold]
        ControlLook.FixedGradientHoverFrom = clGray
        ControlLook.FixedGradientHoverTo = clWhite
        ControlLook.FixedGradientDownFrom = clGray
        ControlLook.FixedGradientDownTo = clSilver
        ControlLook.DropDownHeader.Font.Charset = DEFAULT_CHARSET
        ControlLook.DropDownHeader.Font.Color = clWindowText
        ControlLook.DropDownHeader.Font.Height = -11
        ControlLook.DropDownHeader.Font.Name = 'Tahoma'
        ControlLook.DropDownHeader.Font.Style = []
        ControlLook.DropDownHeader.Visible = True
        ControlLook.DropDownHeader.Buttons = <>
        ControlLook.DropDownFooter.Font.Charset = DEFAULT_CHARSET
        ControlLook.DropDownFooter.Font.Color = clWindowText
        ControlLook.DropDownFooter.Font.Height = -11
        ControlLook.DropDownFooter.Font.Name = 'Tahoma'
        ControlLook.DropDownFooter.Font.Style = []
        ControlLook.DropDownFooter.Visible = True
        ControlLook.DropDownFooter.Buttons = <>
        Filter = <>
        FilterDropDown.Font.Charset = DEFAULT_CHARSET
        FilterDropDown.Font.Color = clWindowText
        FilterDropDown.Font.Height = -11
        FilterDropDown.Font.Name = 'Tahoma'
        FilterDropDown.Font.Style = []
        FilterDropDown.TextChecked = 'Checked'
        FilterDropDown.TextUnChecked = 'Unchecked'
        FilterDropDownClear = '(All)'
        FilterEdit.TypeNames.Strings = (
          'Starts with'
          'Ends with'
          'Contains'
          'Not contains'
          'Equal'
          'Not equal'
          'Larger than'
          'Smaller than'
          'Clear')
        FixedRowHeight = 22
        FixedFont.Charset = DEFAULT_CHARSET
        FixedFont.Color = clWindowText
        FixedFont.Height = -11
        FixedFont.Name = 'Tahoma'
        FixedFont.Style = [fsBold]
        FloatFormat = '%.2f'
        HoverButtons.Buttons = <>
        HoverButtons.Position = hbLeftFromColumnLeft
        HTMLSettings.ImageFolder = 'images'
        HTMLSettings.ImageBaseName = 'img'
        PrintSettings.DateFormat = 'dd/mm/yyyy'
        PrintSettings.Font.Charset = DEFAULT_CHARSET
        PrintSettings.Font.Color = clWindowText
        PrintSettings.Font.Height = -11
        PrintSettings.Font.Name = 'Tahoma'
        PrintSettings.Font.Style = []
        PrintSettings.FixedFont.Charset = DEFAULT_CHARSET
        PrintSettings.FixedFont.Color = clWindowText
        PrintSettings.FixedFont.Height = -11
        PrintSettings.FixedFont.Name = 'Tahoma'
        PrintSettings.FixedFont.Style = []
        PrintSettings.HeaderFont.Charset = DEFAULT_CHARSET
        PrintSettings.HeaderFont.Color = clWindowText
        PrintSettings.HeaderFont.Height = -11
        PrintSettings.HeaderFont.Name = 'Tahoma'
        PrintSettings.HeaderFont.Style = []
        PrintSettings.FooterFont.Charset = DEFAULT_CHARSET
        PrintSettings.FooterFont.Color = clWindowText
        PrintSettings.FooterFont.Height = -11
        PrintSettings.FooterFont.Name = 'Tahoma'
        PrintSettings.FooterFont.Style = []
        PrintSettings.PageNumSep = '/'
        SearchFooter.FindNextCaption = 'Find &next'
        SearchFooter.FindPrevCaption = 'Find &previous'
        SearchFooter.Font.Charset = DEFAULT_CHARSET
        SearchFooter.Font.Color = clWindowText
        SearchFooter.Font.Height = -11
        SearchFooter.Font.Name = 'Tahoma'
        SearchFooter.Font.Style = []
        SearchFooter.HighLightCaption = 'Highlight'
        SearchFooter.HintClose = 'Close'
        SearchFooter.HintFindNext = 'Find next occurrence'
        SearchFooter.HintFindPrev = 'Find previous occurrence'
        SearchFooter.HintHighlight = 'Highlight occurrences'
        SearchFooter.MatchCaseCaption = 'Match case'
        SearchFooter.ResultFormat = '(%d of %d)'
        ShowDesignHelper = False
        SortSettings.DefaultFormat = ssAutomatic
        Version = '8.3.2.4'
        ColWidths = (
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64
          64)
        RowHeights = (
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22
          22)
      end
    end
  end
  object tmrDisplayOff: TTimer
    Enabled = False
    OnTimer = tmrDisplayOffTimer
    Left = 1052
    Top = 24
  end
end
